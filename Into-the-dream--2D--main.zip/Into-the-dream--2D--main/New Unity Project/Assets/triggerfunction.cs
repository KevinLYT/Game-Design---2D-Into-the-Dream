using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class triggerfunction : MonoBehaviour
{
    public UnityEvent triggerevent;
    public UnityEvent triggerexit;
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Player")
        {
            triggerevent.Invoke();
        }
    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.tag == "Player")
        {
            triggerexit.Invoke();
        }
    }
}
