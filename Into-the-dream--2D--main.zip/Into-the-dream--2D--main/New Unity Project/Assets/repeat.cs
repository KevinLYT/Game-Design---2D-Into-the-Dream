using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class repeat : MonoBehaviour
{
    public Vector2 origin;

    public float time = 7.0f;
    
    // Start is called before the first frame update
    void Start()
    {
        origin = transform.position;
        
    }
    // Update is called once per frame
    void Update()
    {
        time -= Time.deltaTime;
        if (time < 0)
        {
            transform.position = origin;
            gameObject.SetActive(false);
            time = 7.0f;
        }
    }
}
