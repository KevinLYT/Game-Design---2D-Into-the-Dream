﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Gamekit2D
{
    [CustomEditor(typeof(Damageable))]
    public class DamageableEditor : DataPersisterEditor
    {}
}