using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
public class TwoPlayerCameraFollower : MonoBehaviour
{
    [SerializeField]private GameObject mirrorEllen;

    [SerializeField]private GameObject ellen;
    public Transform mirrorPos1;
    public Transform enableMirPos1;
    public Transform mirrorPos2;
    public Transform enableMirPos2;
    public Transform mirrorPos3;
    public Transform enableMirPos3;
    private GameObject newEllen;
    
    private Vector3 oriPos;

    public AudioSource _AudioSource;
    public AudioClip _AudioClip1;
    public AudioClip _AudioClip2;

    public CinemachineVirtualCamera vcam;
    // Start is called before the first frame update
    void Start()
    {
        oriPos = transform.position;
        //mainCamera=GetComponent<Camera>();
         _AudioSource.clip = _AudioClip1;
 
         _AudioSource.Play();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (newEllen)
        {
            transform.position = (ellen.transform.position + newEllen.transform.position) / 2;
            Debug.Log(transform.position);
            vcam.m_Lens.FieldOfView = 80;
        }
        else
        {
            transform.localPosition = Vector3.zero;
            vcam.m_Lens.FieldOfView = 50;
        }

        if (Input.GetKeyDown(KeyCode.M))
        {
            if (!newEllen)
            {


                if (enableMirPos1.position.x-0.5 <= ellen.transform.position.x && enableMirPos1.position.x+0.5 >= ellen.transform.position.x)
                {
                    CreateEllen1();
                     _AudioSource.clip = _AudioClip2;
 
                     _AudioSource.Play();
                }
                if (enableMirPos2.position.x-0.5 <= ellen.transform.position.x && enableMirPos2.position.x+0.5 >= ellen.transform.position.x)
                {
                    CreateEllen2();
                     _AudioSource.clip = _AudioClip2;
 
                    _AudioSource.Play();
                }
                if (enableMirPos3.position.x-0.5 <= ellen.transform.position.x && enableMirPos3.position.x+0.5 >= ellen.transform.position.x)
                {
                    CreateEllen3();
                     _AudioSource.clip = _AudioClip2;
 
                    _AudioSource.Play();
                }
            }
            else
            {
                DestroyNewEllen();
 
                 _AudioSource.clip = _AudioClip1;
 
                 _AudioSource.Play();
 
            }
        }

        
    }

    void CreateEllen1()
    {
        newEllen = Instantiate(mirrorEllen, mirrorPos1);
        newEllen.transform.position = mirrorPos1.position;
        newEllen.transform.SetParent(null);
    }
    
    void CreateEllen2()
    {
        newEllen = Instantiate(mirrorEllen, mirrorPos2);
        newEllen.transform.position = mirrorPos2.position;
        newEllen.transform.SetParent(null);
    }
    
    void CreateEllen3()
    {
        newEllen = Instantiate(mirrorEllen, mirrorPos3);
        newEllen.transform.position = mirrorPos3.position;
        newEllen.transform.SetParent(null);
    }

    void DestroyNewEllen()
    {
        Destroy(newEllen);
    }
}
