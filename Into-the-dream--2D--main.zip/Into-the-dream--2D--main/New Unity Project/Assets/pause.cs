using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class pause : MonoBehaviour
{
    public PlayableDirector pa;
    
    // Start is called before the first frame update
    void Start()
    {
        pa.Pause();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
